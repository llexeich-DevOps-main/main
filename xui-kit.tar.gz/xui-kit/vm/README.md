# Тестовая VM для практики с 3x-ui

Задача: поднять Ubuntu 24.04 на своём компе, прогнать `bin/deploy.sh`, добиться
«всё зелёное» в `bin/verify.sh`, и **тем же скриптом** развернуть на реальном VPS.

> VM — это полигон для отладки скрипта, а **не** заготовка для переноса.
> Переносить саму VM на сервер не нужно (почему — см. `../MANUAL.md`, раздел 1.4).

---

## Способ 1. QEMU/KVM + virt-install (Linux, самый нативный)

```bash
sudo apt install -y qemu-kvm libvirt-daemon-system virtinst cloud-image-utils
sudo systemctl enable --now libvirtd

# cloud-init seed: сразу получаем root-доступ без интерактивной установки
mkdir -p ~/vm/xui && cd ~/vm/xui
cat > user-data <<'EOF'
#cloud-config
hostname: xui-vm
users:
  - name: root
    lock_passwd: false
    ssh_authorized_keys: []
chpasswd:
  expire: false
  users:
    - name: root
      password: root
      type: text
runcmd:
  - [ systemctl, enable, --now, ssh ]
EOF
echo "instance-id: xui-vm-001" > meta-data
cloud-localds seed.img user-data meta-data

wget https://cloud-images.ubuntu.com/releases/24.04/release/ubuntu-24.04-server-cloudimg-amd64.img

virt-install --name xui-vm \
  --memory 2048 --vcpus 2 \
  --disk ubuntu-24.04-server-cloudimg-amd64.img,bus=virtio \
  --disk seed.img,device=cdrom \
  --os-variant ubuntu24.04 \
  --import --graphics none --console pty,target_type=serial \
  --network network=default
```
Логин `root` / пароль `root`. IP машины виден в `virsh domifaddr xui-vm`.

**Проброс портов наружу (чтобы Hiddify на телефоне достал до VM):**
```bash
# узнать IP VM
virsh domifaddr xui-vm
# пробросить на хост (пример для 443/tcp; повторить для всех портов из config.env)
sudo iptables -t nat -A PREROUTING -p tcp --dport 443 -j DNAT --to-destination <IP_VM>:443
sudo iptables -t nat -A PREROUTING -p udp --dport 443 -j DNAT --to-destination <IP_VM>:443
sudo iptables -A FORWARD -d <IP_VM> -j ACCEPT
```
Порты, которые надо пробросить: `443/tcp 443/udp 8443/tcp 2053/tcp 2087/udp 2096/tcp 2096/udp`.
Проще всего для практики: **не пробрасывать**, а проверять всё с самой VM (`curl`, `verify.sh`),
а Hiddify тестировать уже на боевом сервере.

---

## Способ 2. Multipass (самый быстрый, 3 команды)

```bash
sudo snap install multipass
multipass launch --name xui --cpus 2 --memory 2G --disk 15G 24.04
multipass info xui          # здесь будет IP
multipass shell xui
# внутри:
sudo -i
```
Проброс портов у Multipass — через `multipass mount` + `iptables` на хосте, либо
`--network` с bridge. Для практики достаточно проверок внутри VM.

---

## Способ 3. VirtualBox (GUI, если привычнее)

1. New → Ubuntu (64-bit) → 2 ГБ RAM → 15 ГБ диск.
2. Settings → Network → **Bridged Adapter** (тогда VM получит IP из твоей домашней сети
   и до неё можно будет достучаться с телефона напрямую). Это сильно удобнее NAT.
3. Settings → System → Processor → 2 CPU.
4. Ставишь Ubuntu Server 24.04 (без GUI).
5. `sudo -i` → копируешь kit → `bash bin/deploy.sh`.

При Bridged-адаптере `PUBLIC_HOST` = IP, который DHCP выдал VM (например `192.168.1.50`).

---

## Способ 4. Docker (быстро, но с оговорками)

```bash
docker run -d --name xui --privileged \
  -p 443:443 -p 443:443/udp -p 8443:8443 -p 2053:2053 \
  -p 2087:2087/udp -p 2096:2096 -p 2096:2096/udp \
  -v xui-db:/etc/x-ui -v xui-cert:/root/cert \
  ubuntu:24.04 sleep infinity
docker exec -it xui bash
# внутри:
apt update && apt install -y curl jq systemd iproute2 procps
```
⚠️ Оговорки:
- `--privileged` нужен для nftables и для kernel-mode WARP.
- systemd внутри контейнера капризен → `deploy.sh` может ругаться на `systemctl`.
  Для чистоты эксперимента лучше VM.
- **BBR и UDP-буферы настраиваются на хосте**, а не в контейнере → проверка `sysctl`
  в `verify.sh` покажет значения хоста.

Рекомендация: **Docker — только чтобы пощупать панель. Для полноценной практики бери VM.**

---

## Как прогнать kit на VM

```bash
# 1. скопировать kit
scp -r xui-kit root@<IP_VM>:/root/xui-kit        # с хоста
#   или внутри VM:
#   mkdir -p /root/xui-kit && cd /root/xui-kit   (и перенести файлы как удобно)

# 2. настроить
cd /root/xui-kit
nano config.env
#   PUBLIC_HOST="<IP_VM>"        например 192.168.122.50
#   SSL_MODE="selfsigned"
#   SETUP_FIREWALL="false"       на VM лучше выключить, чтобы не порезать SSH

# 3. сначала «вхолостую» — посмотреть план, ничего не меняя
bash bin/deploy.sh --dry-run

# 4. боевой прогон
bash bin/deploy.sh

# 5. проверки
bash bin/verify.sh
bash bin/show.sh
cat state/REPORT.md
```

### Особенности VM, о которых надо знать

| Симптом на VM | Почему | Что делать |
|---|---|---|
| `PUBLIC_HOST=192.168.x.x` и телефон не подключается | Телефон не в той сети / NAT | либо bridged-сеть, либо тестировать с самой VM, либо пробросить порты |
| `nftables` режет SSH | policy drop + не открыт 22 | в kit порт 22 открыт всегда; но на VM проще `SETUP_FIREWALL="false"` |
| BBR не включается | старое ядро хоста виртуализации | не критично для практики |
| `scanRealityTargets` медленный/пустой | из VM нет прямого выхода | задай `REALITY_TARGETS_A` вручную известным сайтом |
| hysteria2 не коннектится из Hiddify | self-signed CA не импортирован | импортировать `state/ca.crt` в устройство |
| WARP не регистрируется | из сети VM нет доступа к `engage.cloudflareclient.com:2408` | проверить `nc -vzu engage.cloudflareclient.com 2408`; на VPS обычно работает |

---

## Когда VM-практика закончена

1. Прогоняешь `bin/verify.sh` до состояния `FAIL: 0`.
2. Фиксируешь `config.env` — это и есть твоя «идеально выверенная система».
3. Покупаешь VPS (см. `../HOSTING_REPORT.md` в корне воркспейса — там подбор хостера).
4. На VPS меняешь в `config.env` **только** `PUBLIC_HOST`, `SSL_MODE=acme`, `ACME_EMAIL`, `ACME_CF_TOKEN`.
5. `bash bin/deploy.sh` → `bash bin/verify.sh` → готово.

Всё, что ты отладил на VM, переносится **как код**, а не как образ диска.
