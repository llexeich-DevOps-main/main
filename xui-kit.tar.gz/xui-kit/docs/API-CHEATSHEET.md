# Шпаргалка по API панели 3x-ui v3.11.0

Всё ниже извлечено из `docs/public/openapi.json` (188 эндпоинтов) и исходников
`internal/web/controller/`, `internal/sub/`, `internal/database/model/`.
Живая спека твоей панели: `https://HOST:PORT/BASE/panel/api/openapi.json`
и человекочитаемая страница `https://HOST:PORT/BASE/panel/api-docs`.

## Аутентификация

```bash
TOKEN="..."     # из /etc/x-ui/install-result.env (XUI_API_TOKEN) или из state/state.env
BASE="https://127.0.0.1:PORT/BASE/panel/api"
curl -sk -H "Authorization: Bearer $TOKEN" "$BASE/server/status"
```

- Bearer-токен **освобождает от CSRF** (`internal/web/middleware/security.go:38`:
  «bearer (api_authed) callers skip it»).
- Токены имеют **scope**: `admin`, `node-sync`, `node-admin`, `monitor`
  (`internal/web/controller/api.go`, `monitorScopeAllow` / `nodeSyncScopeAllow`).
- Выпустить новый: `POST /setting/apiTokens/create` `{"name":"x","scope":"admin","expiresAt":0}`
  → **plaintext возвращается один раз**, в БД хранится SHA-256.
- Без токена можно через сессию: `POST /login` `{"username","password"}` + cookie-jar.

## Конверт ответа (важно!)

Все ответы: `{"success":bool,"msg":str,"obj":...}`.
Проверка успеха: `jq -e '.success == true'`.

**Грабли двойной упаковки** — два места, где JSON лежит внутри строки:

| Эндпоинт | Что в `.obj` | Как читать |
|---|---|---|
| `POST /xray/` | **строка** с JSON, внутри `xraySetting` — **ещё строка** с конфигом | `jq -r '.obj' \| jq -c '(.xraySetting \| if type=="string" then fromjson else . end)'` |
| `GET /server/getNewX25519Cert` | объект `{"privateKey","publicKey"}` | `jq -r '.obj.privateKey'` |

## Инбаунды

```
GET  /inbounds/list                 все инбаунды (полные)
GET  /inbounds/list/slim            облегчённый список
GET  /inbounds/get/{id}
POST /inbounds/add                  создать
POST /inbounds/update/{id}          обновить
POST /inbounds/del/{id}
POST /inbounds/bulkDel
POST /inbounds/setEnable/{id}
POST /inbounds/{id}/subSortIndex    порядок в подписке
GET,POST /inbounds/{id}/fallbacks
GET  /inbounds/allLinks             ВСЕ share-ссылки всех инбаундов
GET  /inbounds/options
POST /inbounds/import
POST /inbounds/{id}/resetTraffic
POST /inbounds/resetAllTraffics
POST /inbounds/{id}/delAllClients
```

### Точный payload: VLESS + REALITY + Vision
(форма — из golden-фикстуры `inbound-full/vless-tcp-reality.json`)
```json
{
  "remark": "reality-a",
  "enable": true,
  "listen": "",
  "port": 443,
  "protocol": "vless",
  "expiryTime": 0,
  "total": 0,
  "subSortIndex": 1,
  "excludeFromSub": false,
  "shareAddrStrategy": "custom",
  "shareAddr": "vpn.example.com",
  "tag": "in-reality-a",
  "settings": { "clients": [], "decryption": "none", "encryption": "none", "fallbacks": [] },
  "streamSettings": {
    "network": "tcp",
    "tcpSettings": { "header": { "type": "none" } },
    "security": "reality",
    "realitySettings": {
      "show": false, "xver": 0,
      "target": "www.microsoft.com:443",
      "serverNames": ["www.microsoft.com"],
      "privateKey": "<x25519 private>",
      "minClientVer": "", "maxClientVer": "", "maxTimediff": 0,
      "shortIds": ["a3f1b8c2"],
      "settings": {
        "publicKey": "<x25519 public>",
        "fingerprint": "firefox",
        "serverName": "",
        "spiderX": "/"
      }
    }
  },
  "sniffing": { "enabled": true, "destOverride": ["http","tls","quic","fakedns"],
                "metadataOnly": false, "routeOnly": false }
}
```
⚠️ Поле называется **`target`**, а не `dest` (в `docs/.../config/reality.mdx` в примере
показан `dest` — это упрощение для xray-core; панель хранит `target`).

### Точный payload: Hysteria2
(в панели это `protocol: "hysteria"` + `settings.version: 2`;
`docs/.../config/inbounds.mdx:62-72`)
```json
{
  "remark": "hy2-a",
  "enable": true, "listen": "", "port": 443,
  "protocol": "hysteria",
  "subSortIndex": 3,
  "shareAddrStrategy": "custom", "shareAddr": "vpn.example.com",
  "tag": "in-hy2-a",
  "settings": { "version": 2, "clients": [] },
  "streamSettings": {
    "network": "udp",
    "security": "tls",
    "tlsSettings": {
      "serverName": "vpn.example.com",
      "minVersion": "1.2", "maxVersion": "1.3",
      "certificates": [{ "certificateFile": "/root/cert/x.crt", "keyFile": "/root/cert/x.key",
                         "oneTimeLoading": false, "usage": "encipherment", "buildChain": true }],
      "alpn": ["h3"],
      "settings": { "fingerprint": "" }
    },
    "sockopt": { "tcpcongestion": "bbr", "tcpFastOpen": false, "tcpMptcp": false, "tcpNoDelay": true }
  },
  "sniffing": { "enabled": false, "destOverride": ["http","tls","quic","fakedns"] }
}
```

### FinalMask у Hysteria2 (обфускация и port hopping)
Добавляется в `streamSettings.finalmask`. **Проверено тестом:** добавлять надо пайпом
`.streamSettings.finalmask = $fm`, а НЕ через `A + {streamSettings:(.streamSettings+…)}` —
в jq у правого операнда `+` точка ссылается на правый объект, и такая запись затирает `tlsSettings`.

```json
"finalmask": {
  "udp": [ { "type": "salamander", "settings": { "password": "минимум4байта" } } ],
  "quicParams": {
    "congestionControl": "bbr",
    "udpHop": { "ports": "30000-40000", "interval": "30" }
  }
}
```
- `salamander` / `gecko` — UDP-обфускация. Пароль **минимум 4 байта**, иначе xray-core
  отказывается открыть сокет (`internal/util/maskcompat/salamander.go:SalamanderMinPSK`).
- `udphop` — **клиентская** маска. На инбаунде hopping задаётся legacy-ключом
  `quicParams.udpHop`, панель сама конвертирует его в `udphop`
  (`internal/util/maskcompat/udphop.go:UpgradeLegacyUDPHop`) и ставит последней в списке
  (`NormalizeUDPHop`). В ссылках это параметр `mport`, в JSON-подписке — маска `udphop`.
- **Сервер слушает свой порт** (`docs/.../transports.mdx:157-166`) → диапазон hopping
  надо открывать в файрволе и проверять на реальном сервере. В kit по умолчанию выключено.
- `salamander`/`gecko` ломают masquerade под HTTP/3 — включать только если DPI режет QUIC.

### Точный payload: xhttp
(форма — из `stream/xhttp-basic.json`)
```json
"streamSettings": {
  "network": "xhttp",
  "xhttpSettings": { "path": "/a7f3k9", "host": "vpn.example.com", "mode": "packet-up",
                     "maxConnections": 0, "keepAlivePeriod": 40, "noGRPCHeader": false,
                     "scMaxEachPostBytes": 0, "scMinPostsIntervalMs": 0, "scMaxBufferedPosts": 0 },
  "security": "tls",
  "tlsSettings": { "...": "реальный сертификат" }
}
```
Режимы: `auto` | `packet-up` | `stream-up` | `stream-one`.

**`scMinPostsIntervalMs = 30` — DPI-отпечаток (#5141).** v3.11.0 вырезает дефолтные значения
сам в трёх местах: `internal/sub/service.go:2689`, `internal/sub/json_service.go:809-814`,
`internal/util/link/outbound.go:677`. Ставь `0` (или нестандартный диапазон `20-40`), но не `30`.

## Клиенты

```
POST /clients/add            {"client":{...},"inboundIds":[1,2,3,...]}
GET  /clients/get/{email}
GET  /clients/list           /clients/list/paged
POST /clients/update/{email}
POST /clients/del/{email}
POST /clients/{email}/attach    /clients/{email}/detach
POST /clients/bulkCreate  bulkAdd bulkDel bulkAttach bulkDetach bulkEnable bulkDisable bulkAdjust
GET  /clients/links/{email}        все share-ссылки клиента
GET  /clients/subLinks/{subId}     готовые подписочные URL
GET  /clients/export          POST /clients/import
POST /clients/resetTraffic/{email}    /clients/resetAllTraffics
POST /clients/lastOnline  /clients/onlines  /clients/onlinesByGuid
GET,POST /clients/hwids/{email}        привязка к «железу» устройства
POST /clients/happLink/{id}            ссылка для клиента Happ
```

**Самое полезное** (цитата из OpenAPI-описания `clients/add`):
> «Create a client and attach it to one or more inbounds in a single call.
> Per-protocol secrets are generated server-side when omitted… Re-adding an email that already
> exists, with its stored `subId`, reuses the stored `id`, `password`, `auth` and `secret`
> instead of minting new ones, so the identity stays in sync across its inbounds.»

→ **один вызов = клиент во всех инбаундах, с одним SubID и авто-сгенерированными секретами.**
Повторный вызов идемпотентен. Генерируется сервером при отсутствии: `id` (UUID) для VLESS/VMess,
`password` для Trojan/Shadowsocks, `auth` для Hysteria, `secret` для mtproto,
`privateKey`/`publicKey`/`allowedIPs` для WireGuard.

## Подписка

```
GET /{subPath}{subid}            base64-список ссылок (vless://, hysteria2://, …)
GET /{subJsonPath}{subid}        Xray/sing-box JSON (subJsonEnable)
GET /{subClashPath}{subid}       Mihomo/Clash YAML (subClashEnable)
GET /mihomo/{subid}              алиас Clash-пути
GET /clash-legacy/{subid}        только для мёртвого Clash for Windows
GET /{subPath}{subid}/hwid-status
```
`?html=1` или `Accept: text/html` → человекочитаемая страница вместо тела.

Настройки (`POST /setting/all` → править → `POST /setting/update`):

| Ключ | Дефолт | Смысл |
|---|---|---|
| `subEnable` | **true** | сервер подписки включён |
| `subPort` | 2096 | порт (отдельный процесс!) |
| `subPath` | `/<16 случайных>/` | путь base64-подписки |
| `subJsonPath` / `subClashPath` | случайные / `/mihomo/` | пути JSON и Clash |
| `subJsonEnable` / `subClashEnable` | false | включить форматы |
| `subURI` | `""` | **публичный префикс**; если пусто — берётся хост из запроса |
| `subDomain` | `""` | если задан — отвечать только на этот Host |
| `subCertFile` / `subKeyFile` | `""` | если заданы — подписка по HTTPS |
| `subEncrypt` | true | base64-кодировать тело |
| `subUpdates` | 12 | `Profile-Update-Interval`, часов |
| `subJsonMux` | — | JSON-строка с настройками mux для JSON-подписки |
| `subTitle` / `subSupportUrl` / `subAnnounce` | — | брендинг в заголовках |
| `subJsonFinalMask` | — | маски (hopping, salamander) в JSON-подписку |

Заголовки ответа: `Subscription-Userinfo` (upload/download/total/expire),
`Profile-Update-Interval`, `Profile-Title`, `Support-Url`, `Profile-Web-Page-Url`, `Announce`.

## Xray: шаблон, outbounds, WARP, роутинг

```
POST /xray/                     шаблон + inboundTags + outboundTestUrl (см. двойную упаковку!)
POST /xray/update               form: xraySetting=<JSON шаблона>, outboundTestUrl=<url>
GET  /xray/getDefaultJsonConfig
POST /xray/testOutbound         {"tag":"warp","url":"https://www.google.com/generate_204"}
POST /xray/testOutbounds
POST /xray/routeTest            спросить у ядра, через какой outbound пойдёт трафик
GET  /xray/getXrayResult
GET  /xray/getOutboundsTraffic   POST /xray/resetOutboundsTraffic
POST /xray/warp/{data,del,config,reg,regMasque,changeIp,license,interval}
POST /xray/nord/{action}        NordVPN (NordLynx)
POST /xray/pia/{action}         Private Internet Access (WireGuard)
GET,POST /xray/outbound-subs    импорт пула серверов как outbounds
POST /xray/balancerOverride  /balancerStatus
GET  /xray/geodata/{files,categories,entries}   POST /xray/geodata/validate
```

**WARP** (`docs/.../operations/outbounds-routing.mdx`): создаёшь WireGuard-outbound с тегом
`warp` → `POST /xray/warp/reg` → панель сама заполняет ключи, адреса, reserved и endpoint.
`changeIp` — ротация, `interval` — авто-ротация в днях, `license` — WARP+,
`regMasque` — отдельное устройство для MASQUE.

**Привязка инбаунда к WARP** делается routing-правилом в шаблоне:
```json
{ "type": "field", "inboundTag": ["in-reality-warp","in-hy2-warp"], "outboundTag": "warp" }
```
Инбаунду для этого нужен `tag` (`internal/database/model/model.go:74`, unique).

⚠️ **Не путать** с `PanelEgressInboundTag = "panel-egress"` и `Node.OutboundTag`
(`internal/web/service/xray.go:490-565`) — это loopback-SOCKS-мост для исходящего трафика
**самой панели/ноды**, а не для клиентских инбаундов.

## Сервер

```
GET  /server/status              CPU/RAM/аптайм/статус xray
GET  /server/getXrayVersion      /getPanelUpdateInfo  /getUpdateStatus
POST /server/restartXrayService  /stopXrayService
POST /server/installXray/{version}
POST /server/updatePanel         /setUpdateChannel
POST /server/logs/{count}        /xraylogs/{count}   /amneziawglogs/{count}
GET  /server/getNewUUID
GET  /server/getNewX25519Cert    -> {"privateKey","publicKey"}
GET  /server/getNewmldsa65  /getNewmlkem768  /getNewVlessEnc  /getNewEchCert
POST /server/scanRealityTarget   form: target, sni, xver, allowPrivate
POST /server/scanRealityTargets  form: targets=host:port,host:port,...
GET  /server/getDb               бэкап всей БД
POST /server/importDB            восстановление
GET  /server/getConfigJson       финальный собранный config.json
GET  /server/getWebCertFiles  /getCertHash  /getRemoteCertHash
GET,POST /server/clientIps
GET  /server/fail2banStatus
GET  /server/xrayMetricsState  /xrayMetricsHistory/{metric}/{bucket}
GET  /server/xrayObservatory   /xrayObservatoryHistory/{tag}/{bucket}
GET  /server/cpuHistory/{bucket}  /history/{metric}/{bucket}
GET  /server/descendants
POST /backuptotgbot
```

### scanRealityTargets — авто-подбор таргета
Ответ: массив `RealityScanResult` (`internal/web/service/reality_scan.go:53-78`):
```
target host ip port feasible privateTarget tls13 tlsVersion h2 alpn x25519 curveID
certValid certChainValid certChainBytes certSubject certIssuer notAfter
serverNames[] latencyMs reason
```
Выбирать надо по: `feasible && tls13 && x25519 && certChainValid`, сортировка по `latencyMs`.
`certChainBytes >= 3500` нужен для ML-DSA-65 REALITY.

## Настройки панели

```
POST /setting/all                ВСЕ настройки (секреты приходят пустыми)
POST /setting/update             сохранить (пустой секрет = «не менять»)
POST /setting/defaultSettings    /factoryDefaults
GET  /setting/getDefaultJsonConfig
POST /setting/updateUser         сменить логин/пароль админа
POST /setting/restartPanel
POST /setting/validateRegex
GET  /setting/apiTokens          POST /setting/apiTokens/create
POST /setting/apiTokens/delete/{id}   /setEnabled/{id}
POST /setting/testSmtp  testTgBot  testDiscord  tgBotCapabilities
```
⚠️ `POST /setting/update` принимает **весь** объект `AllSetting` → правильный паттерн:
прочитать `/setting/all`, изменить нужные поля через `jq`, отправить обратно.
`xrayTemplateConfig` в `AllSetting` **не входит** (хранится отдельно, `setting.go:2041`).

## Мультиноды (несколько серверов в одной панели)

```
GET  /nodes/list      POST /nodes/add     GET /nodes/get/{id}   POST /nodes/update/{id}
POST /nodes/del/{id}  POST /nodes/setEnable/{id}
POST /nodes/probe/{id}   POST /nodes/test   POST /nodes/inbounds
GET  /nodes/webCert/{id}   POST /nodes/certfingerprint
POST /nodes/mtls/{ca,trustCA,reloadClient}   POST /nodes/updatePanel
GET  /nodes/history/{id}/{metric}/{bucket}
```
Поле ноды: `outboundTag` — у каждой ноды **свой** egress (например свой WARP).
Для «основной + запасной сервер в одной подписке» это правильная схема
(`docs/.../operations/multi-node.mdx`).

## Hosts и группы (кастомные шаблоны подписки)

```
GET  /hosts/list   /hosts/raw   /hosts/tags   /hosts/get/{groupId}   /hosts/byInbound/{inboundId}
POST /hosts/add  /hosts/bulk/add  /hosts/update/{groupId}  /hosts/del/{groupId}
POST /hosts/bulk/del  /hosts/bulk/setEnable  /hosts/setEnable/{groupId}  /hosts/reorder
GET,POST /sub-balancers    POST,DELETE /sub-balancers/{id}
GET  /clients/groups       POST /clients/groups/{create,delete,rename,resetTraffic,bulkAdd,bulkRemove}
```
Hosts позволяют подменить адрес/порт/SNI в подписке для отдельного инбаунда
(например, отдавать xhttp через другой домен) и добавить `fm`-маски.

## Прочее

```
GET  /csrf-token        POST /login  /logout  /getTwoFactorEnable
GET  /openapi.json      живая спека
GET  /ws                websocket панели
GET  /sponsors
```

## Протоколы инбаундов (полный список v3.11.0)

`internal/database/model/model.go:71`:
```
vmess vless trojan shadowsocks wireguard hysteria http mixed tunnel tun
mtproto amneziawg tuic masque
```
- `hysteria` + `settings.version=2` → Hysteria2, ссылки `hysteria2://`
- `amneziawg` — обфусцированный WireGuard, **внутри процесса панели** (не xray)
- `tuic` — QUIC v5, тоже in-process native Go
- `masque` — CONNECT-IP поверх HTTP/3 или HTTP/2, всегда за TLS;
  отдаётся клиентам **только через JSON-подписку**
- `mtproto` — отдельный процесс `mtg`

## Поля инбаунда, которые стоит знать

| Поле | Зачем |
|---|---|
| `tag` | unique; нужен для routing-правил (WARP) |
| `shareAddrStrategy` | `node` \| `listen` \| `custom` — что подставлять в ссылки |
| `shareAddr` | сам адрес при `custom` → **ключ к переносимости** |
| `excludeFromSub` | держать инбаунд рабочим, но скрыть из подписки |
| `subSortIndex` | порядок ссылок в подписке |
| `disableFlow` | отключить Vision |
| `nodeId` | если инбаунд живёт на ноде, а не на центральной панели |
| `trafficReset` | `never\|hourly\|daily\|weekly\|monthly` + `trafficResetDay` |
| `originNodeGuid` | для синхронизации между нодами |

Логика выбора адреса в ссылках (`internal/sub/service.go:resolveInboundAddress`):
`custom` → `[shareAddr, nodeAddr, listenAddr]`; `listen` → `[listenAddr, nodeAddr]`;
`node` → `[nodeAddr, listenAddr]`; если все пустые → `subDomain`, затем `webDomain`, затем адрес панели.
