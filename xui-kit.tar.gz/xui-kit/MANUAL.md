# Полный мануал: автономная и переносимая 3x-ui-система

> Собрано и проверено по исходникам **3x-ui v3.11.0** (релиз 25.10.2026), по встроенной в панель
> OpenAPI-спеке (188 эндпоинтов) и по официальной документации проекта (`docs/content/docs/en/`).
> Каждое утверждение ниже имеет ссылку на файл/строку в репозитории — можно перепроверить.

---

## Часть 1. Ответы на твои вопросы

### 1.1 «Как делаются ISO-шники?»

Коротко — три разных механизма, и их постоянно путают:

| Механизм | Что это | Как делается | Пригоден ли тебе |
|---|---|---|---|
| **Live/Install ISO** | Загрузочный образ с установщиком | `xorriso -as mkisofs` + `isolinux`/`grub` + squashfs корневого раздела | ❌ Overkill: ты бы писал собственный установщик Ubuntu |
| **Custom cloud image** («своя ОС») | Готовый диск (qcow2/raw), который хостер грузит как образ | Берёшь официальный Ubuntu cloud image → грузишь в VM → настраиваешь → `sysprep` (`virt-sysprep` / `cloud-init clean`) → выгружаешь диск | ⚠️ Технически да, но **бесполезно на дешёвом VPS** |
| **cloud-init user-data** | Текстовый YAML/скрипт, который облако исполняет при **первой** загрузке стокового образа | Пишешь `#cloud-config` файл, вставляешь в поле при создании сервера | ✅ **Вот это тебе и нужно** |

Как реально делается qcow2-образ (если всё же захочешь):
```bash
# скачать официальный cloud image
wget https://cloud-images.ubuntu.com/releases/24.04/release/ubuntu-24.04-server-cloudimg-amd64.img
# создать диск побольше и расширить
qemu-img create -f qcow2 -b ubuntu-24.04-server-cloudimg-amd64.img -F qcow2 disk.qcow2 20G
# запустить VM, настроить, выключить
qemu-system-x86_64 -m 2048 -drive file=disk.qcow2,if=virtio -nic user,hostfwd=tcp::2222-:22
# ОБЯЗАТЕЛЬНО очистить машинные идентификаторы, иначе все клоны будут «одной машиной»
virt-sysprep -a disk.qcow2       # или внутри: cloud-init clean --logs --seed && rm /etc/machine-id
qemu-img convert -O qcow2 -c disk.qcow2 xui-template.qcow2
```
`virt-sysprep`/`cloud-init clean` — критичный шаг: без него machine-id, SSH host keys,
DHCP-leases и seed cloud-init остаются от твоей VM, и второй экземпляр поведёт себя непредсказуемо.

### 1.2 «Мне по факту пригодится просто обычная Ubuntu, в которую я загружу всё по сконфигурированным портам»

**Именно так, и это правильный инстинкт.** Но «загружу» ≠ «запеку в образ». Правильная форма:

> **Стоковая Ubuntu + один идемпотентный скрипт, который поднимает всю архитектуру за один запуск.**

Разница принципиальная:

| | Запечённый образ (ISO/qcow2) | Скрипт поверх стоковой Ubuntu |
|---|---|---|
| Работает на дешёвом VPS (Hetzner-подобные, ProfitServer, Skystark…) | ❌ загрузка своего ISO есть только у dedicated-провайдеров и у немногих VPS (Aeza, LiteServer, PQ) | ✅ везде, где есть SSH |
| Секреты (пароль панели, x25519-ключи REALITY, UUID) | ❌ **одинаковые во всех копиях** → одна утечка образа = компрометация всех серверов | ✅ генерируются на месте, уникальны для каждого сервера |
| IP-адрес | ❌ запечён, на новой машине не работает | ✅ подставляется из конфига |
| Обновление панели/ядра/xray | ❌ пересобирать образ | ✅ `bash bin/deploy.sh` ещё раз |
| Откат/починка | ❌ только переустановка | ✅ скрипт идемпотентен, чинит сам |
| Проверяемость («я сам понимаю, что происходит») | ❌ чёрный ящик | ✅每一步 печатается и проверяется |

**Вывод: ISO — плохая идея. cloud-init user-data + скрипт — хорошая.**
И это ровно тот путь, который выбрал сам проект 3x-ui: в репозитории лежит
`deploy/cloud-init/cloud-init.yaml` с официальным unattended-режимом
(`docs/content/docs/en/guide/installation.mdx`, раздел «Unattended / cloud-init»).

### 1.3 «3x-ui же именно генерирует подписку, она не хардкод?»

**Правильно, генерирует. Хардкода нет.** Механика (проверено по коду):

1. Подписка — это **отдельный HTTP-сервер**, не часть панели
   (`docs/.../config/subscription.mdx`: «The subscription server runs as a **separate** server from the panel»).
2. URL собирается так: `https://<host>:<subPort>/<subPath><SubID>`
   (`internal/sub/controller.go:347` — роут `gLink.GET(":subid", ...)`, где `gLink = g.Group(a.subPath)`).
3. **`SubID`** — это поле клиента, а не его email. Один SubID может быть привязан к клиенту
   в нескольких инбаундах → **одна ссылка отдаёт все его конфиги сразу**.
4. Формат выбирается **путём**, каждый со своим тумблером:
   - `<subPath><SubID>` → base64-список ссылок `vless://`, `hysteria2://` … (включён всегда)
   - `<subJsonPath><SubID>` → **полный sing-box/Xray-JSON конфиг** (`subJsonEnable`)
   - `<subClashPath><SubID>` → Mihomo/Clash YAML (`subClashEnable`)
   - `/mihomo/<SubID>` → алиас для Clash Verge Rev / Mihomo
5. Дефолты из `internal/web/service/setting.go`: `subEnable=true`, `subPort=2096`,
   `subPath=/<16 случайных символов>/` (генерируется при первом запуске,
   `internal/database/db.go:1508`), `subJsonEnable=false`, `subClashEnable=false`,
   `subEncrypt=true`, `subUpdates=12`.
6. В ответе приходят заголовки `Subscription-Userinfo` (upload/download/total/expire),
   `Profile-Update-Interval`, `Profile-Title` → Hiddify сам подхватит остаток трафика и срок.

**Hiddify** умеет и base64-список, и JSON-подписку. Для твоего стека (reality + hysteria2 + xhttp)
надёжнее всего **base64-список ссылок**: Hiddify парсит `vless://…security=reality` и `hysteria2://` нативно.
JSON-подписку включаем тоже — она даёт sing-box-конфиг с `finalmask` (port hopping, salamander),
которого нет в обычных ссылках.

⚠️ **Один нюанс, который ломает всех новичков:** если `subURI` пустой, панель берёт хост
**из HTTP-запроса** (`internal/web/service/setting.go:1936-1950`: `extractHostname(host)`).
Значит, если ты зайдёшь по `http://192.168.122.50:2053`, подписка будет отдавать ссылки
на `192.168.122.50` — и на телефоне это не заработает. Лечится **`subURI`** (жёстко задать
внешний адрес) или **`subDomain`**. В kit это настраивается автоматически из `PUBLIC_HOST`.

### 1.4 «А если конфигурация сохранится под виртуалку на моём компе, при переносе на сервер не заработает?»

**Твоя тревога абсолютно обоснована — но решается она не «не сохранять», а правильным сохранением.**

Что именно привязано к машине:

| Что | Привязано к машине? | Как решается в kit |
|---|---|---|
| IP-адрес в ссылках | **Да** | Поле инбаунда `shareAddrStrategy: "custom"` + `shareAddr: <домен>` (`internal/database/model/model.go:77-78`, `internal/sub/service.go:resolveInboundAddress`). В ссылки подставляется **домен**, а не IP машины |
| `subURI` подписки | **Да** | Задаётся из `PUBLIC_HOST`, а не из запроса |
| Сертификат TLS (для hysteria2/xhttp) | **Да** (в нём CN/SAN = домен) | Домен один и тот же на VM и на VPS → сертификат переносится; либо генерируется заново за 5 секунд |
| x25519-ключи REALITY | **Нет** (это не про IP) | Генерируются на месте, сохраняются в state-файл |
| UUID клиентов, SubID | **Нет** | Сохраняются в state-файл → подписка не меняется |
| Порты | **Нет** | В `config.env` |
| `tag` инбаундов (для WARP-роутинга) | **Нет** | В `config.env` |

**Правильная модель работы (именно так и надо):**

```
        config.env  ←── единственный источник правды (порты, домен, клиенты)
             │
   ┌─────────┴─────────┐
   ▼                   ▼
 VM на твоём ПК      Реальный VPS
 (PUBLIC_HOST=       (PUBLIC_HOST=
  192.168.122.50)     vps.example.com)
   │                   │
   └── один и тот же bin/deploy.sh ──┘
```

VM — это **полигон для отладки скрипта**, а не заготовка для переноса.
Ты прогоняешь `deploy.sh` на VM, добиваешься «всё зелёное» в `verify.sh`,
потом **тем же скриптом** разворачиваешь на VPS, поменяв одну строку `PUBLIC_HOST`.
Переносить саму VM не нужно и вредно.

Если всё же хочешь «сохранить и перенести» — правильный инструмент это **не образ диска**,
а **бэкап БД панели**: `POST /panel/api/server/getDb` → файл, и на новой машине
`POST /panel/api/server/importDB`. Но и это перенесёт старый IP внутрь конфигов,
так что `deploy.sh` заново — чище.

### 1.5 «Может уже есть кастомные ISO-web?»

Есть, и все они решают **не ту** задачу:

| Инструмент | Что делает | Почему не то |
|---|---|---|
| **Cubic** (Custom Ubuntu ISO Creator) | GUI: распаковывает ISO → chroot → ставишь пакеты → собираешь новый ISO | Это про **live-дистрибутив**, а не про VPS. Хостер его не загрузит |
| **Packer** (HashiCorp) | Собирает машинные образы (AMI, qcow2, VMDK) из декларативного описания | Правильный инструмент для «своего образа», но требует, чтобы хостер принимал свои образы |
| **cloud-init** | Официальный стандарт автоконфига при первой загрузке | ✅ **Это оно.** Поддерживается Hetzner, AWS, DO, Vultr, GCP, Azure, Oracle — и самим 3x-ui |
| **Ansible / Docker-compose** | Конфигурация уже работающей машины | ✅ Docker-вариант у 3x-ui есть из коробки (`ghcr.io/mhsanaei/3x-ui`), но на 1 ГБ RAM лучше systemd |
| **Готовые «VPN-ISO»** (различные форки) | Обычно устаревший 3x-ui + чужие ключи | ❌ Категорически нет: чужие секреты = чужой доступ к твоему трафику |

**Вывод:** «кастомный ISO-web» тебе не нужен. Нужен **cloud-init user-data** (для VPS, где он есть)
и **один идемпотентный скрипт** (для всех остальных случаев, включая VM на твоём ПК).
Оба в kit есть и используют один и тот же код.

### 1.6 «Чтобы я сам понимал, что происходит. Через UI, желательно»

Тут две вещи, и kit закрывает обе:

1. **UI панели 3x-ui** — после развёртывания всё, что сделал скрипт, **видно в веб-интерфейсе**
   как обычные объекты: 7 инбаундов в `Inbounds`, клиенты в `Clients`, подписка в
   `Panel Settings → Subscription`, WARP в `Xray Settings → Outbounds → WARP`,
   роутинг в `Xray Settings`. Скрипт ничего не прячет в «магические» файлы — он работает
   **через тот же API, что и UI**. Ты можешь кликами поправить любое поле, и это не сломает систему.
2. **Понятный вывод самого скрипта** — 10 пронумерованных фаз, каждая печатает что делает,
   что получилось и что проверено; в конце — `REPORT.md` с таблицей портов, всеми ссылками,
   QR-кодами и списком предупреждений. Плюс `bin/verify.sh` прогоняет 12 проверок и рисует
   `[ OK ] / [FAIL] / [WARN]` по каждой.

---

## Часть 2. Архитектура, которую разворачивает kit

### 2.1 Семь инбаундов и порты

| # | remark | Протокол | Порт | Транспорт / Security | tag | В подписке |
|---|---|---|---|---|---|---|
| 1 | `reality-a` | vless | **443/tcp** | tcp + **reality**, flow `xtls-rprx-vision` | `in-reality-a` | 1-й |
| 2 | `reality-b` | vless | **8443/tcp** | tcp + **reality** (другой таргет + другой shortId) | `in-reality-b` | 2-й |
| 3 | `hy2-a` | hysteria (v2) | **443/udp** | tls + alpn `h3`, BBR | `in-hy2-a` | 3-й |
| 4 | `hy2-b` | hysteria (v2) | **2096/udp** | tls + **port hopping 30000-40000** + salamander | `in-hy2-b` | 4-й |
| 5 | `reality-warp` | vless | **2083/tcp** | tcp + reality → egress через **WARP** | `in-reality-warp` | 5-й |
| 6 | `hy2-warp` | hysteria (v2) | **2087/udp** | tls → egress через **WARP** | `in-hy2-warp` | 6-й |
| 7 | `xhttp` | vless | **2096/tcp** | **xhttp** + tls (за Cloudflare) | `in-xhttp` | 7-й |

Плюс **сервер подписки**: `2053/tcp` (за оранжевым облаком CF — `SUB_DOMAIN`) (в `config.env` — `SUB_PORT`).

Почему именно так:
- **443/tcp и 443/udp не конфликтуют** — это разные сокеты. Reality на TCP/443, hysteria2 на UDP/443.
- **2096/tcp (xhttp) и 2096/udp (hy2-b)** — тоже не конфликтуют.
- **2053, 2087, 2096, 8443** — это порты, которые **Cloudflare пропускает через оранжевое облако**
  (важно для xhttp: цензор увидит IP Cloudflare, а не твоего хостера).
- **Port hopping** у hy2-b нужен, если оператор троттлит длинные UDP-сессии на одном порту.
  В xray-core ≥26.9.9 hopping живёт в маске `finalmask.udp[type=udphop]`, а старый
  `finalmask.quicParams.udpHop` игнорируется — kit пишет **оба** варианта
  (`internal/sub/service.go:1656-1676` читает и то и другое).
- **Два reality-инстанса с разными SNI/shortId** — чтобы 7 клиентов не долбились в один SNI
  (сигнал «>3 параллельных TLS-хендшейка к одному SNI» = заморозка на ~120 с).

### 2.2 Как WARP-инбаунды получают выход через WARP

Это самая неочевидная часть, и в интернете её обычно описывают неправильно. Реальная механика v3.11.0:

1. В **шаблон Xray** (`Xray Settings`) добавляется outbound `wireguard` с тегом **`warp`**.
2. Панель **сама регистрирует WARP-аккаунт** и заполняет ключи/адреса/endpoint:
   `POST /panel/api/xray/warp/reg` (в OpenAPI описано: «reg — register (sends keys)»,
   также есть `regMasque`, `changeIp`, `license`, `interval` — авто-ротация IP).
3. Инбаунду задаётся **`tag`** (поле `Tag string json:"tag" gorm:"unique"`,
   `internal/database/model/model.go:74`).
4. В `routing.rules` шаблона добавляется правило:
   ```json
   { "type": "field", "inboundTag": ["in-reality-warp", "in-hy2-warp"], "outboundTag": "warp" }
   ```
5. Панель применяет это **горячо**, без рестарта ядра (`internal/xray/hot_diff.go`).

⚠️ Не путай с `OutboundTag` у нод (`internal/database/model/model.go:847`) и с
`PanelEgressInboundTag = "panel-egress"` (`internal/web/service/xray.go:491`) —
это **другой** механизм: он делает loopback-SOCKS-мост для исходящего трафика **самой панели/ноды**,
а не для клиентских инбаундов. Для клиентского WARP нужен именно routing-рул по `inboundTag`.

Проверка, что WARP действительно работает: клиент подключается к `reality-warp`
и на `https://api.ip.sb/geoip` видит IP Cloudflare WARP, а не IP твоего VPS.

### 2.3 Подписка: одна ссылка на все 7 конфигов

```
POST /panel/api/clients/add
{
  "client": { "email": "user1", "totalGB": 0, "expiryTime": 0, "limitIp": 0, "enable": true },
  "inboundIds": [1, 2, 3, 4, 5, 6, 7]
}
```
Цитата из OpenAPI-описания этого метода:
> «Create a client and **attach it to one or more inbounds in a single call**.
> Per-protocol secrets are generated server-side when omitted… Re-adding an email that already exists,
> with its stored `subId`, **reuses the stored `id`, `password`, `auth` and `secret`** instead of minting
> new ones, so the identity stays in sync across its inbounds.»

То есть: **один вызов = клиент во всех 7 инбаундах с одним SubID и автоматически сгенерированными
секретами** (UUID для vless, `auth` для hysteria). Это ровно то, что нужно, и это официальный API —
никакого хака. Дальше:

```
GET /panel/api/clients/subLinks/{subId}   → готовые ссылки-подписки
GET /panel/api/clients/links/{email}      → все share-ссылки клиента
```

И сама подписка для Hiddify:
```
https://<PUBLIC_HOST>:<SUB_PORT>/<subPath><SubID>
```

**7 клиентов = 7 разных SubID = 7 разных ссылок.** Каждая даёт доступ ко всем 7 конфигам.
Это правильная модель: если один клиент «светит» свою ссылку, ты отключаешь только его.

### 2.4 Ловушка `scMinPostsIntervalMs` — уже исправлена в v3.11.0

Раньше (и это задокументировано в wiki.zapret.moe) 3x-ui 3.x.x вшивал в xhttp-конфиг
`"scMinPostsIntervalMs": "30"` и `"scMaxEachPostBytes": "1000000"`, и первое значение
эмпирически триггерило ТСПУ на мобильных сетях РФ.

В v3.11.0 это **исправлено в самом проекте**, причём в трёх местах:
- `internal/sub/service.go:2689` — «the literal `scMinPostsIntervalMs=30` is a known DPI fingerprint (#5141)»
- `internal/sub/json_service.go:809-814` — удаляет оба ключа, если значения дефолтные
- `internal/util/link/outbound.go:677` — «No `scMaxEachPostBytes`/`scMinPostsIntervalMs` seed»

Правило такое: **дефолтные значения вырезаются, нестандартные — оставляются**.
Значит, если хочешь тонко настроить — ставь не `30`, а, например, `20-40`
(диапазон допустим, см. `internal/database/model/model_test.go:203`).

**Поэтому kit пиннит версию `v3.11.0` явно**, а не тянет «latest»:
```bash
bash <(curl -Ls https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh) v3.11.0
```
(синтаксис пиннинга — из `docs/.../guide/installation.mdx`, раздел «pinned version»).

---

## Часть 3. Пошаговая инструкция

### Шаг 0. Что тебе понадобится

- Linux-машина или VM: **Ubuntu 22.04/24.04** или Debian 12, root-доступ.
- Для VM: 2 vCPU / 2 ГБ RAM / 15 ГБ диска (минимум 1 vCPU / 1 ГБ — скрипт создаст swap).
- `bin/deploy.sh` сам доставит `curl jq openssl sqlite3 qrencode` через apt.
- (Опционально, для реального сервера) домен + DNS A-запись → тогда будет настоящий TLS-сертификат.

### Шаг 1. Поднять VM (если практикуешься локально)

См. `vm/README.md` — там 4 способа (QEMU/KVM, VirtualBox, Multipass, Docker) с готовыми командами.
Самый быстрый на Linux:
```bash
sudo apt install -y qemu-kvm libvirt-daemon-system virtinst cloud-image-utils
sudo virt-install --name xui-vm --memory 2048 --vcpus 2 --disk size=15 \
  --os-variant ubuntu24.04 --graphics none --console pty,target_type=serial \
  --location https://cloud-images.ubuntu.com/releases/24.04/release/ubuntu-24.04-server-cloudimg-amd64.img
```
Или совсем просто — Multipass:
```bash
sudo snap install multipass
multipass launch --name xui --cpus 2 --memory 2G --disk 15G 24.04
multipass shell xui          # ты внутри Ubuntu
sudo -i                      # и сразу root
```

### Шаг 2. Скопировать kit на машину

```bash
# если kit лежит на твоём хосте:
scp -r xui-kit root@<IP_VM>:/root/xui-kit
# или прямо на VM:
git clone <твой репо> /root/xui-kit      # если содержишь в git
cd /root/xui-kit
```

### Шаг 3. Настроить `config.env`

Открой `config.env` и поправь **три** вещи (остальное можно оставить как есть):

```bash
PUBLIC_HOST=""          # пусто = автоопределение IP. На VM: 192.168.122.50. На VPS: домен или IP
SSL_MODE="selfsigned"   # selfsigned | none | acme
CLIENTS="user1 user2 user3 user4 user5 user6 user7"
```

Про `SSL_MODE`:
- `selfsigned` — **для VM/практики**: генерируется свой CA + сертификат на `PUBLIC_HOST`.
  Клиенту (Hiddify) нужно один раз импортировать CA — kit кладёт его в `state/ca.crt` и печатает QR.
  Без этого hysteria2/xhttp не подключатся (они требуют валидный TLS).
- `none` — только reality-инбаунды будут работать (reality не нуждается в своём сертификате).
  Годится, чтобы быстро пощупать панель.
- `acme` — **для боевого сервера с доменом**: Let's Encrypt через DNS-01 (Cloudflare) или HTTP-01.
  Тогда сертификат настоящий, клиентам ничего импортировать не надо.

### Шаг 4. Запустить развёртывание

```bash
sudo bash bin/deploy.sh
```

Скрипт идёт по 10 фазам и **печатает каждую**:

```
[1/10] PREFLIGHT ......... root, ОС, архитектура, RAM, порты, интернет, VM/VPS
[2/10] SYSTEM ............ BBR, UDP-буферы, swap, лимиты, nftables
[3/10] 3X-UI ............. установка v3.11.0 (unattended), API-токен
[4/10] TLS ............... сертификат (selfsigned/acme/none)
[5/10] PANEL ............. subEnable/subPort/subPath/subURI/json/clash, безопасность панели
[6/10] XRAY TEMPLATE ..... outbound warp + routing-правила по inboundTag
[7/10] WARP .............. регистрация WARP через API панели (опционально)
[8/10] INBOUNDS .......... 7 инбаундов (идемпотентно: есть tag → update)
[9/10] CLIENTS ............ N клиентов × 7 инбаундов одним вызовом + SubID
[10/10] VERIFY + REPORT ... 12 проверок, REPORT.md, QR-коды
```

Каждая фаза **проверяет результат** и при ошибке останавливается с внятным сообщением,
а не продолжает сыпать искрами. Повторный запуск безопасен: инбаунды ищутся по `tag`,
клиенты — по `email`, существующие обновляются, а не дублируются
(гарантия из OpenAPI: «Re-adding an email that already exists… reuses the stored `id`, `password`,
`auth` and `secret`»).

### Шаг 5. Прочитать отчёт

```bash
cat /root/xui-kit/state/REPORT.md
```
Там: URL панели, логин/пароль, API-токен, таблица портов, **подписочные ссылки всех клиентов**,
QR-коды (ASCII + PNG), путь к CA-сертификату, список предупреждений и что делать дальше.

### Шаг 6. Вставить подписку в Hiddify

1. Hiddify → **+** → **Add from URL** → вставить ссылку вида
   `https://sub.<твой-домен>:2053/<subPath><SubID>` → Confirm (точную ссылку печатает `show.sh`).
2. `Settings → Profile → Update interval` = 12 h.
3. Если `SSL_MODE=selfsigned` → сначала импортировать `state/ca.crt`
   (в Android: Settings → Security → Encryption & credentials → Install a certificate → CA certificate).
4. В профиле появятся все 7 конфигов. Hiddify умеет **latency-test** по группе — включи,
   и он сам выберет живой.
5. Проверь: `Settings → Config Options → Remote DNS` = `https://dns.google/dns-query`,
   `Enable Tun` = ON.

### Шаг 7. Добавить ещё клиента

```bash
sudo bash bin/add-client.sh vasya
```
Печатает подписочную ссылку и QR. Ничего больше делать не нужно: клиент сразу во всех 7 инбаундах.

### Шаг 8. Проверить, что всё живо

```bash
sudo bash bin/verify.sh          # 12 проверок, вывод [ OK ]/[FAIL]/[WARN]
sudo bash bin/show.sh            # все ссылки + QR заново
```

---

## Часть 4. Развёртывание на реальном VPS

### Вариант А — cloud-init (если хостер поддерживает; ноль действий после создания)

При создании сервера вставь содержимое `cloud-init/user-data.yaml` в поле
**Cloud config / User data / Cloud-init script**:

| Хостер | Где вставлять |
|---|---|
| Hetzner Cloud | Create Server → **Cloud config** |
| DigitalOcean | Create Droplet → Advanced → **Add Initialization scripts (user data)** |
| Vultr | Deploy → Additional Features → **Cloud-Init User-Data** |
| AWS EC2 | Advanced details → **User data** |
| GCP | `--metadata-from-file user-data=cloud-init.yaml` |
| Azure | `az vm create --custom-data cloud-init.yaml` |
| Oracle Cloud | Show advanced options → Management → **Cloud-init script** |
| ProfitServer / Skystark / ServerAstra и др. | обычно **нет** такого поля → вариант Б |

После загрузки:
```bash
ssh root@<IP> 'cat /root/xui-kit/state/REPORT.md'
```

### Вариант Б — одна команда по SSH (работает везде)

```bash
# с твоей машины, из папки xui-kit:
tar czf - . | ssh root@<IP> 'mkdir -p /root/xui-kit && tar xzf - -C /root/xui-kit'
ssh root@<IP> 'cd /root/xui-kit && sed -i "s|^PUBLIC_HOST=.*|PUBLIC_HOST=<IP_или_домен>|" config.env && bash bin/deploy.sh'
ssh root@<IP> 'cat /root/xui-kit/state/REPORT.md'
```

### Вариант В — kit уже лежит где-то в интернете

Положи папку kit в приватный git-репозиторий или на Cloudflare R2/Pages, и на VPS:
```bash
curl -fsSL https://ТВОЙ-ХОСТ/deploy.sh | sudo bash
```
⚠️ **Не публикуй kit в открытом виде вместе с `state/`** — там секреты.
`state/` должен быть в `.gitignore`.

---

## Часть 5. Безопасность и «чтобы не было мучительно больно»

### 5.1 Что делает kit автоматически
- Панель: случайный порт (не 2053/54321), случайный `webBasePath`, случайные логин/пароль
  (unattended-режим install.sh сам генерирует и пишет в `/etc/x-ui/install-result.env`, mode 600).
- **Fail2ban** включён (`XUI_ENABLE_FAIL2BAN=true`) — банит за превышение `limitIp`.
- **nftables**: открыты только порты из `config.env`; порт панели — только с `ADMIN_ALLOW_IP`, если задан.
- Все секреты — в `/root/xui-kit/state/`, права `700/600`.
- `subPath` — случайные 16 символов, не `/sub/`.
- Подписка отдаётся **только** для `subDomain`, если он задан (защита от сканирования).

### 5.2 Чего kit НЕ делает (сделай сам)
- **Не** публикует `state/` в интернет.
- **Не** заменяет SSH-ключи (но рекомендую: `PermitRootLogin prohibit-password`, `PasswordAuthentication no`).
- **Не** настраивает автобэкап. Минимальный вариант:
  ```bash
  # cron: раз в сутки
  curl -sk -H "Authorization: Bearer $TOKEN" https://HOST:PORT/BASE/panel/api/server/getDb -o /root/backup/x-ui-$(date +%F).db
  ```
  Или через меню `x-ui` → Backup. Бэкап БД = вся конфигурация (инбаунды, клиенты, подписки).

### 5.3 Чек-лист перед тем, как раздать ссылки 7 людям
- [ ] `verify.sh` — все 12 проверок зелёные
- [ ] `PUBLIC_HOST` — это **домен или финальный IP**, а не адрес VM
- [ ] `SSL_MODE=acme` и сертификат настоящий (иначе каждому клиенту придётся ставить твой CA)
- [ ] WARP-инбаунды реально выходят через Cloudflare (`api.ip.sb/geoip` показывает CF)
- [ ] порт панели сменён и закрыт по IP
- [ ] `state/` не попал в git/облако
- [ ] есть запасной сервер **у другого провайдера в другой стране**
- [ ] прогнан `dpi-ch` **из российской сети** (субчекер Siberian) — единственный способ
      узнать, не под подозрительной ли подсетью твой IP

---

## Часть 6. Типовые ошибки

| Симптом | Причина | Фикс |
|---|---|---|
| Hiddify принял ссылку, но 0 конфигов | `subEnable` выключен или `Age Limit ≠ 0` | `Panel Settings → Subscription → Enable Service = ON` |
| Подписка отдаёт ссылки на `192.168.x.x` | `subURI` пустой, панель взяла хост из запроса | задать `subURI` / `subDomain` (kit делает это из `PUBLIC_HOST`) |
| hysteria2 не коннектится, «certificate unknown» | self-signed CA не импортирован в систему клиента | импортировать `state/ca.crt`, либо `SSL_MODE=acme` |
| hysteria2 молчит entirely | UDP зарезан оператором | включить port hopping (инбаунд 4 в kit), MTU 1200; если UDP мёртв — только TCP-каналы |
| xhttp работает из-за рубежа, не работает из РФ на мобильном | старый 3x-ui 3.x с `scMinPostsIntervalMs:30` | **обновиться до v3.11.0** (kit пиннит её); или вручную вырезать ключ из шаблона |
| WARP-инбаунд отдаёт IP VPS, а не Cloudflare | нет routing-правила `inboundTag → outboundTag: warp` | kit добавляет; проверь `Xray Settings → Routing` |
| `Port 443 is already in use` | на машине уже висит nginx/apache | `systemctl disable --now nginx apache2` |
| После переустановки панели подписки «поехали» | сменился `subPath`/SubID | восстановить из `state/state.env` или из бэкапа БД |
| Панель не открывается, хотя xray жив | забыл `webBasePath` | `cat /etc/x-ui/install-result.env` → `XUI_ACCESS_URL` |
| 7 клиентов одновременно → часть отваливается | >3 параллельных TLS-хендшейков на один SNI | mux ON, разные SNI на инстансах (kit делает), не запускать всех залпом |

---

## Часть 7. Справочник: что реально есть в API v3.11.0

Полная спека: `https://HOST:PORT/BASE/panel/api/openapi.json` и UI-страница
`https://HOST:PORT/BASE/panel/api-docs`. Шпаргалка — в `docs/API-CHEATSHEET.md`.

Самое полезное из найденного (чего нет в старых гайдах):

| Эндпоинт | Зачем |
|---|---|
| `POST /panel/api/server/scanRealityTarget` | **автоматический подбор REALITY-таргета** (панель сама проверит сайт) |
| `POST /panel/api/xray/warp/{reg,regMasque,changeIp,license,interval}` | регистрация WARP, ротация IP, WARP+ лицензия |
| `POST /panel/api/clients/add` с `inboundIds[]` | клиент во всех инбаундах одним вызовом |
| `GET /panel/api/clients/subLinks/{subId}` | готовые подписочные URL |
| `GET /panel/api/inbounds/allLinks` | все share-ссылки всех инбаундов |
| `POST /panel/api/xray/routeTest` | спросить у ядра, через какой outbound пойдёт трафик |
| `POST /panel/api/xray/testOutbound` | проверить, что outbound (WARP) живой |
| `GET /panel/api/server/getDb` / `POST importDB` | бэкап/восстановление всей конфигурации |
| `POST /panel/api/setting/apiTokens/create` | выпустить scoped API-токен (`admin` / `node-sync` / `node-admin` / `monitor`) |
| `GET /panel/api/nodes/*` | **мультиноды**: одна панель управляет несколькими серверами |
| `POST /panel/api/hosts/*` | кастомные шаблоны подписки и хосты (подмена адреса, `fm`-маски) |

Про мультиноды отдельно: если у тебя будет 2 сервера (основной + запасной), **не нужно две панели**.
`docs/.../operations/multi-node.mdx` описывает схему «одна центральная панель + N нод»,
причём нода может иметь свой `outboundTag` (свой WARP) — то есть запасной сервер
в той же подписке. Это сильно упрощает отказоустойчивость.

---

## Часть 8. Источники (всё проверяемо)

Локально: `/tmp/x/3x-ui-3.11.0/` (архив `https://codeload.github.com/MHSanaei/3x-ui/tar.gz/refs/tags/v3.11.0`).

| Утверждение | Где проверить |
|---|---|
| Версия v3.11.0, релиз 25.10.2026, теги до v2.4.9 | `GET https://api.github.com/repos/MHSanaei/3x-ui/releases` |
| Unattended-режим + `install-result.env` + список `XUI_*` | `install.sh`, `deploy/cloud-init/README.md`, `docs/.../reference/env-vars.mdx` |
| Пиннинг версии: `bash <(curl …install.sh) v3.4.0` | `docs/.../guide/installation.mdx` |
| Подписка — отдельный сервер, URL = `/<subPath><subid>` | `internal/sub/controller.go:277-358`, `docs/.../config/subscription.mdx` |
| Дефолты `subEnable=true`, `subPort=2096`, случайный `subPath` | `internal/web/service/setting.go:104-188`, `internal/database/db.go:1508` |
| Пустой `subURI` → хост из запроса | `internal/web/service/setting.go:1935-1950` |
| `clients/add` с `inboundIds[]` и стабильным `subId` | `docs/public/openapi.json` → `/panel/api/clients/add` (description) |
| Поля инбаунда: `tag`, `shareAddrStrategy`, `shareAddr`, `excludeFromSub`, `subSortIndex` | `internal/database/model/model.go:53-80` |
| Адрес в ссылках берётся из `shareAddr` при `custom` | `internal/sub/service.go` → `resolveInboundAddress` |
| Hysteria2 = `protocol: "hysteria"` + `settings.version: 2` | `docs/.../config/inbounds.mdx:62-72`, golden fixture `inbound-full/hysteria-tls.json` |
| Port hopping: `finalmask.udp[type=udphop].settings.remotePorts` (+ legacy `quicParams.udpHop`) | `internal/sub/service.go:1656-1686`, `frontend/src/lib/xray/udphop-mask.ts` |
| Salamander-обфускация: `finalmask.udp[type=salamander].settings.password` | golden fixture `finalmask/salamander-gecko.json` |
| Точный payload reality-инбаунда | golden fixture `inbound-full/vless-tcp-reality.json` |
| Точный payload xhttp-транспорта | golden fixture `stream/xhttp-basic.json` |
| `scMinPostsIntervalMs=30` — DPI-отпечаток, вырезается | `internal/sub/service.go:2686-2694`, `internal/sub/json_service.go:809-814`, `internal/util/link/outbound.go:677` |
| WARP: outbound с тегом `warp` + регистрация через панель | `docs/.../operations/outbounds-routing.mdx`, `/panel/api/xray/warp/{action}` |
| `panel-egress` — это другой механизм (не клиентский WARP) | `internal/web/service/xray.go:490-565` |
| Bearer-токен освобождает от CSRF | `internal/web/middleware/security.go:38-40` |
| 188 эндпоинтов API, scopes токенов | `docs/public/openapi.json`, `internal/web/controller/api.go` |
| Протоколы панели: vless, vmess, trojan, shadowsocks, wireguard, hysteria, http, mixed, tunnel, mtproto, **amneziawg**, **tuic**, **masque** | `internal/database/model/model.go:71` |
| xray-core версии 26.9.9+ (псевдо-версия от 21.10.2026) | `go.mod:31` |

## Часть 5. Домен и Cloudflare (на примере assaxaq.online)

`.online` — generic TLD (регистратура Radix, Каймановы острова), страновой юрисдикции нет: для ТСПУ и санкционных списков домен «ничей», важна только инфраструктура за ним.

### 5.1 Схема записей в Cloudflare

| Запись | Тип | Куда | Облако | Зачем |
|---|---|---|---|---|
| `@` (assaxaq.online) | A | IP сервера | **СЕРОЕ** (DNS only) | address для reality/hy2-ссылок: им нужен прямой адрес, CF оранжевое ломает REALITY и UDP |
| `panel` | A | IP сервера | **СЕРОЕ** | панель: `https://panel.assaxaq.online:ПОРТ/путь` с Let's Encrypt, без предупреждений браузера |
| `sub` | A | IP сервера | **ОРАНЖЕВОЕ** (Proxied) | подписка качается через CF: origin-IP не светится в DNS и в TLS-хендшейке |
| `cf` | A | IP сервера | **ОРАНЖЕВОЕ** | xhttp-инбаунд за CF: структурно снимает признак «подозрительная подсеть» (единственный способ по wiki.zapret) |

Правило: **оранжевое облако только для TCP-HTTPS-трафика, который терпит terminating-TLS** (подписка, xhttp). REALITY и hysteria2 — только серое облако: им нужен end-to-end TLS/QUIC до сервера.

### 5.2 Настройки в дашборде Cloudflare

- **SSL/TLS → Overview: mode `Full`** (или `Full (strict)` при `SSL_MODE=acme` — wildcard Let's Encrypt публично доверенный).
- HTTPS-порты, которые CF пропускает через оранжевое облако: **443, 2053, 2083, 2084, 2087, 2096, 8443**. Kit это проверяет в preflight: `SUB_PORT=2053` и `PORT_XHTTP=2096` проходят.
- Кэш: пути подписки (`/<subPath>…`) без расширения файла CF по умолчанию не кэширует; для параноиков — Cache Rule «Bypass» на hostname `sub.*`.
- Не включай «Always Use HTTPS», «Auto Minify», WAF managed rules на записи `cf`/`sub` — они ломают стриминг xhttp (WAF режет длинные POST).

### 5.3 Что делает kit с доменом сам

1. `SSL_MODE=acme` + `ACME_DNS_PROVIDER=dns_cf` + `ACME_CF_TOKEN` → acme.sh выпускает **wildcard** (`assaxaq.online` + `*.assaxaq.online`) через DNS-01: никакие порты 80/443 для проверки не нужны.
2. Сертификат ставится и на сервер подписки, и на xhttp/hy2, и на панель (`PANEL_SSL_MODE=domain` → `x-ui cert` кладёт его в `/root/cert/<PANEL_DOMAIN>/` и панель рестартует с HTTPS).
3. `SUB_URI` становится `https://sub.assaxaq.online:2053` — все клиентские ссылки подписки идут через CF.
4. xhttp-инбаунд получает `shareAddr=cf.assaxaq.online` — клиенты ходят в xhttp через оранжевое облако.
5. Reality/hy2 остаются с `shareAddr=assaxaq.online` (серая запись → IP), SNI hysteria2 = apex-домен, покрыт wildcard.
6. `verify.sh` группа 13 проверяет: apex и panel резолвятся напрямую (серое), sub и cf — в диапазоны Cloudflare (оранжевое), подписка отвечает через CF.

Переезд на другой сервер при такой схеме = поменять A-записи в CF + `PUBLIC_HOST` в config.env + перезапуск deploy.sh. Клиентские ссылки на sub/cf не меняются вообще.

## Часть 6. Клиенты с TUN-режимом: Hiddify и NekoBox (Windows / Linux)

Полное туннелирование всего трафика (TUN/VPN-режим) — это свойство КЛИЕНТА, а не подписки: подписка отдаёт outbounds, клиент заворачивает в tun весь системный трафик. Поэтому важно, чтобы клиент (а) распарсил нашу подписку и (б) умел TUN на десктопе.

### 6.1 Hiddify (Windows, Linux, Android, macOS) — основной рекомендованный клиент

- Ядро sing-box; импортирует подписки форматов **Sing-box JSON, V2Ray (base64), Clash, Clash Meta** — kit отдаёт все три (`SUB_ENABLE_JSON/SUB_ENABLE_CLASH`), включая sing-box JSON с mux и finalmask.
- TUN: на десктопе Hiddify работает в VPN/TUN-режиме по умолчанию (sing-box tun); если переключался на System Proxy — вернуть: Settings → Proxy mode → **VPN (TUN)**. Весь трафик системы, включая DNS (с remote-dns через tun), уходит в туннель.
- Импорт: Profiles/+ → Add subscription → вставить ссылку из `show.sh` (`https://sub.assaxaq.online:2053/<subPath><SubID>`) → автообновление каждые `SUB_UPDATES` часов.
- Наши xhttp/hy2/reality-профили sing-box JSON парсятся актуальным sing-box внутри Hiddify (xhttp-transport и hysteria2 salamander поддерживаются; port-hopping sing-box читает из `server_ports`).

### 6.2 NekoBox for PC / NekoRay (Windows, Linux) — работает, с оговоркой

- Проект **архивирован автором в 2024**, но жив в сборках и форках; ядро переключаемое (v2ray-core / sing-box), **TUN-режим есть**: Settings → Enable TUN mode (или «Tun mode» в трее), ядро для TUN — sing-box как system core. Весь системный трафик туннелируется.
- Подписки: base64 (v2rayN-style) и Clash YAML — обе отдаёт kit. Импорт: Group → Add subscription → URL из `show.sh`.
- **Оговорка**: собрание архивное, его sing-box/xray старее xhttp-transport → ссылка xhttp-инбаунда может не распариться (остальные 6 конфигураций импортируются и работают, TUN в том числе). Форки с поддержкой полных JSON-подписок sing-box (например, NyameBox-линейка) забирают все 7.
- Практическая рекомендация: Windows/Linux-машины, которым нужен весь трафик — Hiddify; NekoBox держать как запасной для reality/hy2.

### 6.3 Проверка «весь трафик в туннеле»

После включения TUN на клиенте: `curl https://api.ipify.org` должен показать IP выхода (WARP-инбаунды — IP Cloudflare WARP, прямые — IP сервера), а `traceroute`/`who.is` не должны светить провайдерский IP клиента. DNS-утечки: в Hiddify включён remote DNS через tun по умолчанию; в NekoRay — Settings → DNS → remote.
